-- Status:6:22:MP_0:xinwenda:php:1.24.4:xwd-140108:5.5.31-log:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|xwd_answer|2|65536||InnoDB
-- TABLE|xwd_configs|13|32768||InnoDB
-- TABLE|xwd_flink|3|16384||InnoDB
-- TABLE|xwd_nav|2|16384||InnoDB
-- TABLE|xwd_question|1|49152||InnoDB
-- TABLE|xwd_user|1|49152||InnoDB
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2014-01-08 08:44

--
-- Create Table `xwd_answer`
--

DROP TABLE IF EXISTS `xwd_answer`;
CREATE TABLE `xwd_answer` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `qid` int(10) unsigned NOT NULL DEFAULT '0',
  `title` char(50) NOT NULL COMMENT '标题',
  `author` varchar(15) NOT NULL DEFAULT '',
  `authorid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `adopttime` int(10) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `comment` tinytext NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ip` varchar(20) DEFAULT NULL,
  `tag` text NOT NULL,
  `support` int(10) NOT NULL DEFAULT '0',
  `against` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `qid` (`qid`),
  KEY `authorid` (`authorid`),
  KEY `time` (`time`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Data for Table `xwd_answer`
--

/*!40000 ALTER TABLE `xwd_answer` DISABLE KEYS */;
INSERT INTO `xwd_answer` (`id`,`qid`,`title`,`author`,`authorid`,`time`,`adopttime`,`content`,`comment`,`status`,`ip`,`tag`,`support`,`against`) VALUES ('1','1','测试数据标题','黄春泽','1','4294967295','4294967295','测试数据内容','评论','1','192.168.10.192','餐饮,小吃','0','0');
INSERT INTO `xwd_answer` (`id`,`qid`,`title`,`author`,`authorid`,`time`,`adopttime`,`content`,`comment`,`status`,`ip`,`tag`,`support`,`against`) VALUES ('2','1','测试数据标题','黄春泽','1','4294967295','4294967295','测试数据内容','评论','1','192.168.10.192','餐饮,小吃','0','0');
/*!40000 ALTER TABLE `xwd_answer` ENABLE KEYS */;


--
-- Create Table `xwd_configs`
--

DROP TABLE IF EXISTS `xwd_configs`;
CREATE TABLE `xwd_configs` (
  `id` smallint(5) NOT NULL AUTO_INCREMENT,
  `key` varchar(30) NOT NULL COMMENT '配置属性',
  `value` text NOT NULL COMMENT '配置值',
  `type` enum('string','int','float','bool','array') NOT NULL DEFAULT 'string',
  PRIMARY KEY (`id`),
  UNIQUE KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='网站配置文件';

--
-- Data for Table `xwd_configs`
--

/*!40000 ALTER TABLE `xwd_configs` DISABLE KEYS */;
INSERT INTO `xwd_configs` (`id`,`key`,`value`,`type`) VALUES ('1','site_doname','http://www.7808.com/','string');
INSERT INTO `xwd_configs` (`id`,`key`,`value`,`type`) VALUES ('2','site_name','中国招商加盟网','string');
INSERT INTO `xwd_configs` (`id`,`key`,`value`,`type`) VALUES ('3','site_title','网站的标题','string');
INSERT INTO `xwd_configs` (`id`,`key`,`value`,`type`) VALUES ('4','site_keywords','关键字','string');
INSERT INTO `xwd_configs` (`id`,`key`,`value`,`type`) VALUES ('5','site_description','描述','string');
INSERT INTO `xwd_configs` (`id`,`key`,`value`,`type`) VALUES ('6','mobile','158222222','string');
INSERT INTO `xwd_configs` (`id`,`key`,`value`,`type`) VALUES ('7','email','7808@7808.com','string');
INSERT INTO `xwd_configs` (`id`,`key`,`value`,`type`) VALUES ('8','weibo','http://weibo.com/7808','string');
INSERT INTO `xwd_configs` (`id`,`key`,`value`,`type`) VALUES ('9','qq','55822336','string');
INSERT INTO `xwd_configs` (`id`,`key`,`value`,`type`) VALUES ('10','addr','重庆市区','string');
INSERT INTO `xwd_configs` (`id`,`key`,`value`,`type`) VALUES ('11','is_closed','1','bool');
INSERT INTO `xwd_configs` (`id`,`key`,`value`,`type`) VALUES ('12','beian','fafagf','string');
INSERT INTO `xwd_configs` (`id`,`key`,`value`,`type`) VALUES ('13','code','asdfadf','string');
/*!40000 ALTER TABLE `xwd_configs` ENABLE KEYS */;


--
-- Create Table `xwd_flink`
--

DROP TABLE IF EXISTS `xwd_flink`;
CREATE TABLE `xwd_flink` (
  `id` int(4) unsigned NOT NULL AUTO_INCREMENT COMMENT '友情链接ID',
  `name` varchar(60) NOT NULL COMMENT '链接名称',
  `link` varchar(120) NOT NULL COMMENT '链接地址',
  `mark` varchar(12) NOT NULL COMMENT '所属标记组',
  `img` varchar(250) NOT NULL COMMENT '链接图片',
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COMMENT='友情链接表';

--
-- Data for Table `xwd_flink`
--

/*!40000 ALTER TABLE `xwd_flink` DISABLE KEYS */;
INSERT INTO `xwd_flink` (`id`,`name`,`link`,`mark`,`img`,`created_time`) VALUES ('1','百度','http://www.baidu.com','index','','2014-01-08 15:04:03');
INSERT INTO `xwd_flink` (`id`,`name`,`link`,`mark`,`img`,`created_time`) VALUES ('2','Google','http://www.google.cn/','index','','2014-01-08 15:04:18');
INSERT INTO `xwd_flink` (`id`,`name`,`link`,`mark`,`img`,`created_time`) VALUES ('3','淘宝','http://www.taobao.com','index','','2014-01-08 15:04:37');
/*!40000 ALTER TABLE `xwd_flink` ENABLE KEYS */;


--
-- Create Table `xwd_nav`
--

DROP TABLE IF EXISTS `xwd_nav`;
CREATE TABLE `xwd_nav` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT COMMENT '导航ID',
  `name` char(50) NOT NULL COMMENT '导航名',
  `title` char(255) NOT NULL COMMENT '导航描述',
  `url` char(255) NOT NULL COMMENT '导航链接',
  `target` tinyint(1) NOT NULL DEFAULT '0' COMMENT '打开方式',
  `type` tinyint(1) NOT NULL DEFAULT '0' COMMENT '类型',
  `status` tinyint(1) NOT NULL DEFAULT '0' COMMENT '状态  0：不显示，1：显示',
  `sort` tinyint(3) NOT NULL COMMENT '排序 值大者排前面',
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Data for Table `xwd_nav`
--

/*!40000 ALTER TABLE `xwd_nav` DISABLE KEYS */;
INSERT INTO `xwd_nav` (`id`,`name`,`title`,`url`,`target`,`type`,`status`,`sort`,`created_time`) VALUES ('1','乡村基','乡村基快餐店','http://www.7808.com/ask_admin/','0','0','0','0','2014-01-07 10:18:45');
INSERT INTO `xwd_nav` (`id`,`name`,`title`,`url`,`target`,`type`,`status`,`sort`,`created_time`) VALUES ('2','乡村基','乡村基快餐店','http://www.7808.com/ask_admin/','0','0','0','1','2014-01-07 10:19:04');
/*!40000 ALTER TABLE `xwd_nav` ENABLE KEYS */;


--
-- Create Table `xwd_question`
--

DROP TABLE IF EXISTS `xwd_question`;
CREATE TABLE `xwd_question` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cid` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cid1` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cid2` smallint(5) unsigned NOT NULL DEFAULT '0',
  `cid3` smallint(5) unsigned NOT NULL DEFAULT '0',
  `price` smallint(6) unsigned NOT NULL DEFAULT '0',
  `author` char(15) NOT NULL DEFAULT '',
  `authorid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `title` char(50) NOT NULL,
  `description` text NOT NULL,
  `supply` text NOT NULL,
  `url` varchar(255) NOT NULL DEFAULT '1',
  `time` int(10) unsigned NOT NULL DEFAULT '0',
  `endtime` int(10) unsigned NOT NULL DEFAULT '0',
  `hidden` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `answers` smallint(5) unsigned NOT NULL DEFAULT '0',
  `views` int(10) unsigned NOT NULL DEFAULT '0',
  `goods` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `ip` varchar(20) DEFAULT NULL,
  `search_words` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `answers` (`answers`),
  KEY `authorid` (`authorid`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Data for Table `xwd_question`
--

/*!40000 ALTER TABLE `xwd_question` DISABLE KEYS */;
INSERT INTO `xwd_question` (`id`,`cid`,`cid1`,`cid2`,`cid3`,`price`,`author`,`authorid`,`title`,`description`,`supply`,`url`,`time`,`endtime`,`hidden`,`answers`,`views`,`goods`,`status`,`ip`,`search_words`) VALUES ('1','1','2','3','4','66','黄春泽','1','创建文明社区','创建文明社区','创建文明社区','1','0','0','0','0','0','0','1',NULL,NULL);
/*!40000 ALTER TABLE `xwd_question` ENABLE KEYS */;


--
-- Create Table `xwd_user`
--

DROP TABLE IF EXISTS `xwd_user`;
CREATE TABLE `xwd_user` (
  `uid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `username` char(18) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` varchar(40) NOT NULL COMMENT '邮件',
  `avatar` varchar(100) NOT NULL COMMENT '头像',
  `groupid` tinyint(3) unsigned NOT NULL DEFAULT '7' COMMENT '用户组',
  `credits` int(10) NOT NULL DEFAULT '0',
  `regip` char(15) NOT NULL COMMENT '注册IP',
  `regtime` int(10) NOT NULL DEFAULT '0' COMMENT '注册时间',
  `lastlogin` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登陆时间',
  `gender` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date NOT NULL COMMENT '生日',
  `phone` varchar(30) NOT NULL COMMENT '手机号',
  `qq` varchar(15) NOT NULL,
  `msn` varchar(40) NOT NULL,
  `signature` mediumtext NOT NULL COMMENT '签名',
  `access_token` varchar(50) DEFAULT NULL,
  `questions` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '密保问题id',
  `answers` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '密保答案id',
  `adopts` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '采用答案次数',
  `isnotify` tinyint(1) unsigned NOT NULL DEFAULT '7',
  `expert` tinyint(2) NOT NULL DEFAULT '0' COMMENT '是否过期',
  `created_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Data for Table `xwd_user`
--

/*!40000 ALTER TABLE `xwd_user` DISABLE KEYS */;
INSERT INTO `xwd_user` (`uid`,`username`,`password`,`email`,`avatar`,`groupid`,`credits`,`regip`,`regtime`,`lastlogin`,`gender`,`birthday`,`phone`,`qq`,`msn`,`signature`,`access_token`,`questions`,`answers`,`adopts`,`isnotify`,`expert`,`created_time`) VALUES ('1','admin','7fef6171469e80d32c0559f88b377245','','','7','0','','0','0','0','0000-00-00','','','','',NULL,'0','0','0','7','0','2014-01-06 17:16:04');
/*!40000 ALTER TABLE `xwd_user` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

